// Client Storefront API (GraphQL). Sans variables d'environnement, on renvoie des produits de démonstration.

export type Product = {
  id: string;
  handle: string;
  title: string;
  price: string; // déjà formaté, ex. « 48,00 € »
  image?: { url: string; alt: string; width: number; height: number };
};

const domain = process.env.SHOPIFY_STORE_DOMAIN;
const token = process.env.SHOPIFY_STOREFRONT_TOKEN;
const version = process.env.SHOPIFY_API_VERSION ?? "2025-07";

async function storefront<T>(query: string, variables: Record<string, unknown> = {}): Promise<T> {
  const res = await fetch(`https://${domain}/api/${version}/graphql.json`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Storefront-Access-Token": token!,
    },
    body: JSON.stringify({ query, variables }),
    next: { revalidate: 60, tags: ["products"] },
  });
  if (!res.ok) throw new Error(`Shopify ${res.status}`);
  const json = await res.json();
  if (json.errors) throw new Error(JSON.stringify(json.errors));
  return json.data as T;
}

const PRODUCTS_QUERY = /* GraphQL */ `
  query Products($first: Int!, $country: CountryCode!, $language: LanguageCode!)
  @inContext(country: $country, language: $language) {
    products(first: $first, sortKey: BEST_SELLING) {
      nodes {
        id
        handle
        title
        featuredImage { url altText width height }
        priceRange { minVariantPrice { amount currencyCode } }
      }
    }
  }
`;

const money = (amount: string, currency: string) =>
  new Intl.NumberFormat("fr-FR", { style: "currency", currency }).format(Number(amount));

export async function getProducts(first = 8): Promise<Product[]> {
  if (!domain || !token) return DEMO;
  type R = {
    products: {
      nodes: {
        id: string; handle: string; title: string;
        featuredImage: { url: string; altText: string | null; width: number; height: number } | null;
        priceRange: { minVariantPrice: { amount: string; currencyCode: string } };
      }[];
    };
  };
  const data = await storefront<R>(PRODUCTS_QUERY, { first, country: "FR", language: "FR" });
  return data.products.nodes.map((p) => ({
    id: p.id,
    handle: p.handle,
    title: p.title,
    price: money(p.priceRange.minVariantPrice.amount, p.priceRange.minVariantPrice.currencyCode),
    image: p.featuredImage
      ? { url: p.featuredImage.url, alt: p.featuredImage.altText ?? p.title, width: p.featuredImage.width, height: p.featuredImage.height }
      : undefined,
  }));
}

const DEMO: Product[] = [
  { id: "1", handle: "rouge-scene", title: "Rouge à lèvres mat", price: "48,00 €" },
  { id: "2", handle: "encre-scene", title: "Encre à lèvres liquide", price: "48,00 €" },
  { id: "3", handle: "eau-de-parfum", title: "Eau de parfum", price: "135,00 €" },
  { id: "4", handle: "soin-serum", title: "Sérum concentré", price: "112,00 €" },
];
