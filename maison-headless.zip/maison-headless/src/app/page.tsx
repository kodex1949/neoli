import Link from "next/link";
import { getProducts } from "@/lib/shopify";
import { ProductCard } from "@/components/ProductCard";
import { HeroStory } from "@/components/HeroStory";

export const revalidate = 60;

export default async function Home() {
  const products = await getProducts(8);

  return (
    <>
      {/* Héros animé au scroll : l'image se réduit en carte centrale, deux tuiles montent de chaque côté.
          Passez image="/hero.jpg" et image: "/tile-1.jpg" pour vos visuels. */}
      <HeroStory
        eyebrow="Nouvelle collection"
        title="Le jasmin, nouvel esprit de parfum"
        href="/collections/parfums"
        tiles={[
          { caption: "Un extrait de parfum intense", href: "/collections/parfums" },
          { caption: "Une eau de parfum solaire", href: "/collections/parfums" },
        ]}
      />

      {/* Grille produits */}
      <section className="section">
        <div className="section__head">
          <span className="eyebrow">Les iconiques</span>
          <h2 className="display">Les incontournables de la Maison</h2>
        </div>
        <div className="grid">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      {/* Bloc éditorial image + texte */}
      <section className="editorial">
        <div className="editorial__media" />
        <div className="editorial__body">
          <span className="eyebrow">Nouveauté</span>
          <h2 className="display">Des rouges à lèvres mats sans transfert, 24 h</h2>
          <Link href="/collections/maquillage" className="btn">Découvrir</Link>
        </div>
      </section>

      <section className="section">
        <div className="section__head" style={{ marginBottom: 0 }}>
          <span className="eyebrow">Parfum</span>
          <h2 className="display">La nouvelle icône couture</h2>
          <Link href="/collections/parfums" className="link">Découvrir</Link>
        </div>
      </section>
    </>
  );
}
