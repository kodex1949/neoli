"use client";

import Link from "next/link";
import { useEffect, useRef } from "react";

// Dior bascule l'état « actif » vers 50–60 px de scroll, dans les deux sens.
const ACTIVATE_AT = 56;

type Tile = { caption: string; href: string; image?: string };

type Props = {
  eyebrow: string;
  title: string;
  href: string;
  image?: string; // visuel principal (sinon dégradé de démonstration)
  tiles: [Tile, Tile];
};

export function HeroStory({ eyebrow, title, href, image, tiles }: Props) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    let active = false;

    const update = () => {
      raf = 0;
      const next = window.scrollY > ACTIVATE_AT;
      if (next !== active) {
        active = next;
        el.dataset.active = String(next);
      }
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };

    update(); // état correct si la page est rechargée en cours de scroll
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const bg = (url?: string) => (url ? { backgroundImage: `url(${url})` } : undefined);

  return (
    <section ref={ref} className="story" data-active="false">
      <div className="story__pin">
        <Link href={tiles[0].href} className="story__tile story__tile--start" style={bg(tiles[0].image)}>
          <span className="story__caption">{tiles[0].caption}</span>
          <span className="link">Découvrir</span>
        </Link>

        <div className="story__visual" style={bg(image)}>
          <div className="story__overlay">
            <span className="eyebrow">{eyebrow}</span>
            <h1 className="display">{title}</h1>
            <Link href={href} className="link">Découvrir</Link>
          </div>
        </div>

        <Link href={tiles[1].href} className="story__tile story__tile--end" style={bg(tiles[1].image)}>
          <span className="story__caption">{tiles[1].caption}</span>
          <span className="link">Découvrir</span>
        </Link>
      </div>

      {/* Trait « scroll » animé, masqué dès que le héros est actif */}
      <span className="story__scroller" aria-hidden="true" />
    </section>
  );
}
