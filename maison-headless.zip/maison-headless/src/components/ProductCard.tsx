import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/lib/shopify";

export function ProductCard({ product }: { product: Product }) {
  return (
    <Link href={`/produits/${product.handle}`} className="card">
      <div className="card__media">
        {product.image ? (
          <Image
            src={product.image.url}
            alt={product.image.alt}
            width={product.image.width}
            height={product.image.height}
            sizes="(max-width: 1024px) 50vw, 25vw"
          />
        ) : (
          <div className="card__placeholder" />
        )}
      </div>
      <div>
        <h3 className="card__title">{product.title}</h3>
        <p className="card__price">{product.price}</p>
      </div>
    </Link>
  );
}
