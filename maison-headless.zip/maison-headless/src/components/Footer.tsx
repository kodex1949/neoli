import Link from "next/link";

const cols = [
  { title: "Service client", links: ["Nous contacter", "Livraison", "Retours", "FAQ"] },
  { title: "La Maison", links: ["Notre histoire", "Engagements", "Carrières", "Presse"] },
  { title: "Boutiques", links: ["Trouver une boutique", "Rendez-vous", "Cartes cadeaux"] },
  { title: "Légal", links: ["Mentions légales", "Confidentialité", "Cookies", "CGV"] },
];

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer__cols">
        {cols.map((c) => (
          <div key={c.title}>
            <h3>{c.title}</h3>
            <ul>
              {c.links.map((l) => (
                <li key={l}><Link href="#">{l}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <p className="footer__legal">© {new Date().getFullYear()} Maison. Tous droits réservés.</p>
    </footer>
  );
}
