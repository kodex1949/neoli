import Link from "next/link";

const stroke = { strokeLinecap: "round", strokeLinejoin: "round" } as const;

export function Header() {
  return (
    <header className="header">
      <div className="header__inner">
        <div className="header__side">
          <button className="icon-btn" aria-label="Menu">
            <svg viewBox="0 0 24 24"><path d="M4 9h16M4 15h16" {...stroke} /></svg>
          </button>
          <button className="icon-btn" aria-label="Rechercher">
            <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" {...stroke} /></svg>
          </button>
        </div>

        <Link href="/" className="logo" aria-label="Accueil">Maison</Link>

        <div className="header__side header__side--right">
          <Link href="/compte" className="icon-btn" aria-label="Mon compte">
            <svg viewBox="0 0 24 24"><circle cx="12" cy="8.5" r="3.5" /><path d="M5 20c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5" {...stroke} /></svg>
            <span className="badge" />
          </Link>
          <Link href="/panier" className="icon-btn" aria-label="Panier">
            <svg viewBox="0 0 24 24"><path d="M5 8h14l-1 12H6L5 8Z" {...stroke} /><path d="M9 8V7a3 3 0 0 1 6 0v1" {...stroke} /></svg>
          </Link>
        </div>
      </div>
    </header>
  );
}
